angular.module('logonModule', []).controller('logonController', function($scope,$http) {
	var self = this;
	$scope.logon = function() {
		// Perform validation for user name and password
		alert($scope.user + $scope.password)
//		$http.get('logon/').then(function(response) {
//			self.greeting = response.data;
//		})
	}
}
);