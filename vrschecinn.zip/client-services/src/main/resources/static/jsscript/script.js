	// create the module and name it CheckinnApp
	var CheckinnApp = angular.module('CheckinnApp', ['ngRoute']);

	// configure our routes
	CheckinnApp.config(function($routeProvider) {
		$routeProvider

			// route for the home page
			.when('/', {
				templateUrl : 'pages/logon.html',
				controller  : 'logonController'
			})

			// route for the about page
			.when('/about', {
				templateUrl : 'pages/about.html',
				controller  : 'aboutController'
			})

			// route for the contact page
			.when('/contact', {
				templateUrl : 'pages/contact.html',
				controller  : 'contactController'
			});
	});

	// create the controller and inject Angular's $scope
	CheckinnApp.controller('mainController', function($scope) {
		// create a message to display in our view
		$scope.message = 'Everyone come and see how good I look!';
	});

	CheckinnApp.controller('logonController', function($scope,$http) {
		$scope.logon = function() {
			// Perform validation for user name and password
			$http.get('logon/'+$scope.text+'/'+$scope.password).then(function(response) {
				if(response.data=='success'){
					alert(response.data);	
				}
				
			})
		}

	});

	CheckinnApp.controller('contactController', function($scope) {
		$scope.message = 'Contact us! JK. This is just a demo.';
	});