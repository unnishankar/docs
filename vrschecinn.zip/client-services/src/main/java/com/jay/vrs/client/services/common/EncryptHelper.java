package com.jay.vrs.client.services.common;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class EncryptHelper {

private static final String ENCODER_PASSWORD="11012011!06042015#17051984&&VRSOFTCHECKINN";
	
	
	public static String encyrptMessage(String message) {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(ENCODER_PASSWORD);  
		encryptor.setAlgorithm("PBEWithMD5AndDES");
		String encryptedMsg = encryptor.encrypt(message);
		return encryptedMsg;
	}
	
	public static String encyrptMessage(String message, String password) {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(password);  
		encryptor.setAlgorithm("PBEWithMD5AndDES");
		String encryptedMsg = encryptor.encrypt(message);
		return encryptedMsg;
	}
	
	
	public static void main (String args[]) {
		System.out.println("EncryptHelper: "+ EncryptHelper.encyrptMessage("admin"));
		System.out.println("EncryptHelper: "+ EncryptHelper.encyrptMessage("admin","VRS-0001"));
		System.out.println("EncryptHelper: "+ EncryptHelper.encyrptMessage("admin","VRS-0002"));
		System.out.println("EncryptHelper: "+ EncryptHelper.encyrptMessage("postgres"));
		
		
	}
	

}
