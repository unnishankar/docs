package com.jay.vrs.client.services.feign;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient("user-management")
public interface UserManagement {
	
	@RequestMapping("/serv-logon/{userName}/{password}")
	public String logon(@PathVariable("userName") String userName, @PathVariable("password") String passwords);

}
