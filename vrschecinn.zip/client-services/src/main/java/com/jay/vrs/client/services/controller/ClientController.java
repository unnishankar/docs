package com.jay.vrs.client.services.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jay.vrs.client.services.common.EncryptHelper;
import com.jay.vrs.client.services.feign.UserManagement;

@RestController
public class ClientController {

	@Value("jasypt.encryptor.password")
	private String encoderPassword;
	
	@Autowired
	UserManagement userManagement;
	
	@RequestMapping(value="/logon/{userName}/{password}",method = RequestMethod.GET)
	public String logon(@PathVariable String userName, @PathVariable String password) {
		System.out.println("encoderPassword:"+encoderPassword);
		String user = EncryptHelper.encyrptMessage(userName);
		String pwd = EncryptHelper.encyrptMessage(password);
		String response = userManagement.logon(user,pwd);
		System.out.println("response: "+response);
		return response;
	}
}
